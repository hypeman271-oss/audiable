# Project Brief

This is the second top-level note. No frontmatter — the
filename `Project Brief.md` is used as the chapter title
verbatim.

We start two weeks behind schedule and finish three weeks
ahead. Anyone who tells you the middle was easy is lying.
