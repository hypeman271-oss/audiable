---
title: Welcome — start here
tags: [meta]
---

This is the **Welcome** note. The vault parser should
pull the YAML `title:` and use it instead of the filename.

There's a [[Project Brief]] note in the same folder, plus
a [[Drafts/Chapter 1]] under the Drafts folder. Wikilinks
are flattened to plain text on import; image embeds like
![[cover.png]] are dropped so the audio doesn't read the
filename aloud.
