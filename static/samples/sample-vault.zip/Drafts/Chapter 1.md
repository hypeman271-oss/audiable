# Chapter 1 — The Doorway

Subfolder notes still come through; their folder name shows
in the picker as a subtitle so sister files are easy to
spot. This one references [[Welcome]] to confirm the
wikilink-flattening pass.
