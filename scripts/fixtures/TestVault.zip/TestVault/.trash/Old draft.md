# Old draft

This was deleted by the author.
