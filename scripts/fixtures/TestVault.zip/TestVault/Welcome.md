# Welcome

This vault is where I write my novel.
