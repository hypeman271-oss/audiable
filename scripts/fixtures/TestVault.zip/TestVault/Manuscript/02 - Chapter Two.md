---
title: The Long Crossing
tags: [fiction, draft]
date: 2026-01-15
---

# Chapter Two

The river was wider than Tom had remembered.
