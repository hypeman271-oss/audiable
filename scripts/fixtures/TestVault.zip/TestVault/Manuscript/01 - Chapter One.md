# Chapter One

It was a dark and stormy night when Tom met Huck.

They walked along the river bank, talking of small things.
