# Chapter Three

Tom thought about [[Aunt Polly]] as he walked.

He passed [[The Old Mill|the old mill]] on his way home.

![[map.png]]

![[Other Note]]

Then he kept walking.
