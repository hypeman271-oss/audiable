---
title: The Geography of It All
---

Rivers run north to south.

The capital city is on the east bank of the great river.
